@extends('layouts.layout')

@section('content')
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
testing 
</body>
</html>
@endsection